# VPP Roundtrip Evaluation

**Test date: 27 October 2026.**

VPP completed **1,004 of 1,005 measured roundtrips successfully (99.90%)**.
The median roundtrip time was **470.3 ms**. The p95 time was **1,737.3 ms**.
One reader invocation failed with a read timeout. The evaluator therefore marked
the run as unsuccessful.

These results apply to the storage path at a configured concurrency of 10.
They do not establish a maximum system capacity or a service-level guarantee.

## Test conditions

| Setting | Recorded value |
| --- | --- |
| Twin | VPP |
| AWS region | `eu-west-1` |
| Start time, UTC | 2026-10-27 10:22:05.169 |
| Finish time, UTC | 2026-10-27 10:23:17.558 |
| Evaluation mode | `storage` |
| Maximum concurrent roundtrips | 10 |
| Devices | 201: one Grid device, 100 household Sensors, and 100 household BESS devices |
| Measured messages per device | 5 |
| Total measured messages | 1,005 |
| Warmup messages | 0 |
| Roundtrip deadline | 10 s |
| SDK read timeout | 10 s |
| Poll interval after an unmatched read | 50 ms |

The household range was `Household0001` to `Household0100`. Each message wrote
one configured property:

| Device type | Property | Test value |
| --- | --- | ---: |
| `Grid.telemetry` | `activePowerKW` | 12.5 |
| Household `Sensor` | `chargedEnergyKWh` | 100 |
| Household `BESS` | `stateOfChargePercent` | 50 |

The measured path was:

```text
Evaluation client -> VPP-persister -> storage
Evaluation client -> VPP-hot-reader -> verified response
```

The timer starts immediately before the write. It stops when a decoded reader
response matches both the timestamp and the value sent. The duration includes
client requests and any polling waits. It excludes time waiting for a worker
slot. The IoT publish, dispatcher, and processor paths are outside this test.

## Run results

| Metric | Result |
| --- | ---: |
| Successful measured messages | 1,004 |
| Failed measured messages | 1 |
| Success rate | 99.90% |
| Write errors | 0 |
| Read errors | 1 |
| Samples with status `timeout` | 0 |
| Measured phase duration | 72.391 s |
| Successful messages per second | 13.87 |

The one failed sample has status `read_error`, because the reader request raised
an SDK timeout error. It is not counted under the evaluator's separate
`timeout` status. Throughput is the number of successful measured messages
divided by the full measured phase duration, including scheduling and failed work.

## Latency of successful messages

All values below are in **milliseconds**. The population is the **1,004 successful
measured messages**. The failed sample is excluded from this table.

| Operation | Minimum | Mean | Median (p50) | p95 | p99 | Maximum |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Write | 259.0 | 328.2 | 311.5 | 357.8 | 537.4 | 1,835.2 |
| Read | 108.2 | 353.4 | 152.7 | 1,346.7 | 2,787.7 | 6,401.1 |
| Full roundtrip | 378.9 | 681.6 | 470.3 | 1,737.3 | 3,384.7 | 6,707.2 |

The p95 value means that at least 95% of successful messages completed within
1,737.3 ms. The p99 value is 3,384.7 ms. Percentiles use the nearest-rank method.
Each operation's percentiles are calculated separately; write and read
percentiles must not be added to calculate roundtrip percentiles.

![Roundtrip latency distribution for the 1,004 successful messages](VPP-roundtrip-latency-2026-10-27.png)

**871 successful messages (86.75%) returned in less than one second.**
The remaining 133 successful messages took at least one second. Three took at
least five seconds. The chart excludes the failed message, which took 10.379 s.

The slowest successful message was sent to `Household0015.BESS`. Its write took
306.1 ms, and its reader call took 6,401.1 ms. Its full roundtrip took 6,707.2 ms.
All 1,005 samples made exactly one read attempt. Repeated polling therefore did
not account for the long durations in this run. The records do not identify
the cause of the long reader calls.

## Device coverage

Each of the 201 devices has five measured samples. Of these devices, 200
completed all five samples successfully. `Household0024.BESS` completed four
successfully and had one read error.

| Device type | Devices | Measured messages | Successes | Failures | Roundtrip p50, ms | Roundtrip p95, ms |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Grid | 1 | 5 | 5 | 0 | 552.3 | 3,384.7 |
| Household Sensor | 100 | 500 | 500 | 0 | 469.3 | 1,459.2 |
| Household BESS | 100 | 500 | 499 | 1 | 471.2 | 1,803.5 |
| **Total** | **201** | **1,005** | **1,004** | **1** | **470.3** | **1,737.3** |

Group latency values use successful messages only. The total row is calculated
from all successful messages together. It is not an average of group percentiles.
Grid has only five samples, so its p95 equals its maximum. Five samples per
device are insufficient for a stable estimate of each device's tail latency.

## Failed sample

| Field | Recorded value |
| --- | --- |
| CSV sequence, starting at zero | 48 |
| Target | `Household0024.BESS` |
| Property and value | `stateOfChargePercent = 50` |
| Message timestamp, UTC | 2026-10-27 10:22:10.026 |
| Status | `read_error` |
| Write duration | 369.1 ms |
| Read duration | 10,010.0 ms |
| Full roundtrip duration | 10,379.1 ms |
| Read attempts | 1 |

The recorded error states that the `VPP-hot-reader` Lambda invocation
failed with a **read timeout on the endpoint URL**. The write call returned
without a recorded error, but the evaluator could not verify the matching read.
The data does not show whether that value became readable after the failure.

The 10.379 s roundtrip exceeds the 10 s cycle deadline because an in-flight SDK
request can finish after that deadline. For investigation, review the
`VPP-hot-reader` logs during this run, with attention to the message
timestamp above. These files alone do not establish the cause of the timeout.

## Limits of this result

- This is one run of approximately 72 seconds, with concurrency limited to 10.
  It does not show sustained performance or performance at other load levels.
- No warmup samples were excluded. Startup effects may be present. Cold starts
  were not measured, so the first requests cannot be classified as cold starts.
- Latency statistics describe successful requests. The failed request remains
  visible in the counts and the failure section.
- Client durations include network and service response time. The data does not
  separate Lambda execution, database access, and network delay.
- The test covers the configured storage roundtrip. It does not measure the
  complete IoT ingestion path.
- No acceptance threshold is included in the source files. This report gives the
  observed result without assigning an additional performance pass or fail.

## Sources and calculation notes

- [Recorded run summary](../../cloud-dtc-docker/pipeline/digital-twin-evaluation/output/VPP/d126979ec0de49c29c321667719ed9d3/summary.json)
- [Raw measurements](../../cloud-dtc-docker/pipeline/digital-twin-evaluation/output/VPP/d126979ec0de49c29c321667719ed9d3/measurements.csv)

Run ID: `d126979ec0de49c29c321667719ed9d3`.

The recorded runtime was evaluation service `0.1.0`, Python `3.13.18`, and
Boto3 `1.43.119`. The report uses the plan saved with this run.

Checks against the CSV confirmed 1,005 records, 201 distinct devices, five
samples per device, and no duplicate device/timestamp pairs. Sequences cover
0 through 1,004 without gaps. Counts and latency distributions agree with the
saved summary, including all 201 device summaries.

Success rate is `1,004 / 1,005 * 100 = 99.9005%`, rounded to 99.90%.
Throughput is `1,004 / 72.391297195 = 13.8691` successful messages per second,
rounded to 13.87. For a percentile fraction `p`, nearest rank selects position
`ceil(p * n)` from ascending values, with positions starting at one.

Latency values are rounded to one decimal place. These checks use the original
CSV values before rounding. Percentiles for a device group are calculated from
that group's successful raw samples.
