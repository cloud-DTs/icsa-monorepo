# MGridICSA Roundtrip Evaluation

All 700 measured cycles succeeded across seven devices. Median roundtrip latency was **470.4 ms**.
The 95th percentile was **954.8 ms**. The maximum was **3,320.5 ms**.
These results describe a **sequential storage test** recorded on 26 October 2026.
[Run summary](dcea276da4a444a989eb528863643ec3/summary.json)

**Recorded run.** The elapsed time includes warmup and all measured cycles.
The report uses the effective settings saved with this run.

| Item | Recorded value |
| --- | --- |
| Twin | `MGridICSA` |
| Run ID | `dcea276da4a444a989eb528863643ec3` |
| Start (UTC) | 2026-10-26T19:08:15.208Z |
| Finish (UTC) | 2026-10-26T19:15:17.855Z |
| Elapsed time | 422.647 s (7 min 2.647 s), including warmup |
| AWS region | `eu-west-1` |
| Mode | `storage` |
| Execution | Sequential; one cycle at a time |
| Writer Lambda | `MGridICSA-persister` |
| Reader Lambda | `MGridICSA-hot-reader` |

**Test scope.** The evaluator sent a value from the client to the deployed writer Lambda.
It then requested that record through the deployed reader Lambda.
A cycle succeeded when the reader returned the same timestamp and value.

```text
Evaluation client -> MGridICSA-persister -> DynamoDB -> MGridICSA-hot-reader -> Evaluation client
```

The client invoked Lambda directly. IoT publishing, the dispatcher, and device processor functions were outside this measured path.
The test covered one property for each device:

| Device | Component path | Property | Type | Test value |
| --- | --- | --- | --- | --- |
| Battery | `MicroGrid.battery.p16` | `totalCapacity` | INTEGER | 100 |
| PV | `MicroGrid.pv.pV1` | `output` | DOUBLE | 12.5 |
| Charger 1 | `MicroGrid.charger1.p13` | `consumption` | DOUBLE | 12.5 |
| Charger 2 | `MicroGrid.charger2.p14` | `consumption` | DOUBLE | 12.5 |
| Charger 3 | `MicroGrid.charger3.p12` | `consumption` | DOUBLE | 12.5 |
| Charger 4 | `MicroGrid.charger4.p17` | `consumption` | DOUBLE | 12.5 |
| Charger 5 | `MicroGrid.charger5.p11` | `consumption` | DOUBLE | 12.5 |

The values above are test inputs. The saved results do not specify their physical units.

**Saved settings.** Each device completed 10 warmup cycles, followed by 100 measured cycles.
Devices ran in the table order: battery, PV, then chargers 1 through 5.

| Setting | Saved value |
| --- | --- |
| Measured cycles per device | 100 |
| Warmup cycles per device | 10 |
| Total measured cycles | 700 |
| Total warmup cycles | 70 |
| Roundtrip timeout | 10 s |
| Read polling interval | 0.05 s (50 ms) |
| SDK request timeout | 10 s |

**Observed completion.** All 700 measured cycles and all 70 warmup cycles succeeded.
The CSV contains no write errors, read errors, or timeouts.
Every cycle returned the expected record on its first read attempt.
The 770 records have unique device-and-timestamp keys. [Measurements](dcea276da4a444a989eb528863643ec3/measurements.csv)

**Client latency.** All values in the next table are milliseconds.
The table includes the 700 successful measured cycles. It excludes warmup.

| Client measurement | Minimum | Mean | P50 | P95 | P99 | Maximum |
| --- | --- | --- | --- | --- | --- | --- |
| Write | 268.6 | 358.7 | 320.4 | 570.8 | 1,402.8 | 2,105.2 |
| Read | 109.0 | 182.7 | 149.6 | 368.5 | 929.5 | 2,204.1 |
| Roundtrip | 393.9 | 541.5 | 470.4 | 954.8 | 2,109.0 | 3,320.5 |

Write latency covers the synchronous writer invocation and its response.
Read latency covers the reader invocations and their responses.
Roundtrip latency starts before the write and ends after the evaluator verifies the read result.
These client measurements include communication and Lambda execution time.
They do not provide a separate database operation duration.

P50 is the median under the saved nearest-rank method.
P95 is the value at or below which at least 95% of samples fall. P99 has the same meaning for 99%.
Each stage has its own distribution; stage percentiles cannot be added to obtain the roundtrip percentile.

**Results by device.** Every device contributed 100 measured cycles.
Median values ranged from 464.0 to 479.7 ms.
The battery had the highest P95: 1,698.2 ms.

| Device | Successful / measured | P50 (ms) | P95 (ms) | P99 (ms) | Maximum (ms) |
| --- | --- | --- | --- | --- | --- |
| Battery | 100 / 100 | 479.7 | 1,698.2 | 3,015.8 | 3,320.5 |
| PV | 100 / 100 | 467.3 | 570.0 | 1,028.1 | 1,200.8 |
| Charger 1 | 100 / 100 | 466.3 | 525.6 | 1,455.1 | 2,252.1 |
| Charger 2 | 100 / 100 | 464.0 | 1,118.6 | 1,790.9 | 2,109.0 |
| Charger 3 | 100 / 100 | 475.2 | 547.6 | 1,385.3 | 1,835.7 |
| Charger 4 | 100 / 100 | 472.2 | 743.9 | 1,840.2 | 1,873.0 |
| Charger 5 | 100 / 100 | 465.9 | 846.5 | 1,375.1 | 2,655.0 |

![Roundtrip P50, P95, and P99 latency for seven devices, using 100 measured cycles per device.](roundtrip-latency.png)

**Slower cycles.** 668 of 700 cycles (95.4%) completed within one second.
32 cycles took more than one second. Of those, 8 took more than two seconds.
The three slowest measured cycles were:

| CSV sequence | Device | Start time (UTC, 26 Oct) | Write (ms) | Read (ms) | Roundtrip (ms) |
| --- | --- | --- | --- | --- | --- |
| 106 | Battery | 19:09:24.406 | 2,105.2 | 1,215.3 | 3,320.5 |
| 68 | Battery | 19:08:58.217 | 1,513.0 | 1,502.8 | 3,015.8 |
| 107 | Battery | 19:09:27.726 | 721.4 | 2,204.1 | 2,925.6 |

All three cycles succeeded on their first read attempt.
Devices were tested in separate time windows. These results do not establish why battery cycles had a longer latency tail.

**Interpretation limits.** The run demonstrates successful write-and-read verification for the tested properties and values.
The recorded 100% success rate applies to this sample.
One sequential run cannot establish parallel capacity or long-term availability.
The saved plan has no concurrency parameter and explicitly records sequential execution.

Cold-start data and internal AWS traces were not collected. Warmup does not prove that cold starts were absent.
The reader retained its deployed consistency behavior. The evaluator did not change consistency settings.
No latency service-level objective was supplied, so this report makes no latency acceptance decision.

**Sources and calculation notes.** The saved summary and CSV are the evidence for this report:

- Summary and effective plan: [dcea276da4a444a989eb528863643ec3/summary.json](dcea276da4a444a989eb528863643ec3/summary.json).
- Individual cycles: [dcea276da4a444a989eb528863643ec3/measurements.csv](dcea276da4a444a989eb528863643ec3/measurements.csv).
- Applied deployment state: adapter `manager-state-v1`, applied at `2026-10-22T16:20:48.836904+00:00`.
- Deployment fingerprint: `e619fabf491509854da69cd3b270265780379384123f188a5c85d250d50dd143`.
- Recorded runtime: evaluation service `0.1.0`, Python `3.13.17`, Boto3 `1.43.118`.

Counts and percentiles were recalculated from the CSV and reconciled with the saved global and device summaries.
The mean is the arithmetic mean of successful measured samples.
For percentile p, values are sorted and the sample at position `ceil(p / 100 * n)` is selected.
The global percentiles use all 700 measured values. Device percentiles use 100 values each.
Elapsed time is the difference between the saved UTC start and finish timestamps.
Values are displayed to one decimal place. The source files retain full precision.

Source SHA-256 hashes:

```text
summary.json      0f8c008d6da9d91d7f73fb58cd304262c75c32091b415c163c6a2c92d2bf761c
measurements.csv  8aeb13463bba191c4c83b2011059ccb563cf66a297596d2e9ecf92e83c5d0c75
```
